<template>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-sm-6 mb-4 mb-xl-0">
                <div class="d-lg-flex align-items-center">
                    <div>
                        <h3 class="text-dark font-weight-bold mb-2 text-capitalize">{{ this.$route.name }}</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-info text-center" role="alert">
                    <h1>SELAMAT DATANG DI SIHIPIN POLITEKNIK KAMPAR </h1>
                </div>
                <div class="card">
                    <img src="/assets/images/logop3m.png" class="card-img-top w-50 mx-auto" alt="...">
                </div>
            </div>
        </div>

    </div>
</template>